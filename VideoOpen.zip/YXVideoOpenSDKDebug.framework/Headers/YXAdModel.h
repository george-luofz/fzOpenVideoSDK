//
//  AdModel.h
//  AdSDKDemo
//
//  Created by 深海 on 16/11/4.
//  Copyright © 2016年 一下. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface YXAdModelExposeURL : NSObject

@property (copy, nonatomic , readonly) NSString *imgClickUrl;
@property (copy, nonatomic , readonly) NSString *imgImpUrl;
@property (copy, nonatomic , readonly) NSString *videoAutoUrl;
@property (copy, nonatomic , readonly) NSString *videoOverUrl;
@property (copy, nonatomic , readonly) NSString *videoShowUrl;

- (void)setupMiaozhenURL:(NSDictionary *)dict;
- (void)setupAdmasterURL:(NSDictionary *)dict;

@end

@interface YXAdModel : NSObject

@property (nonatomic , copy)    NSString   *cid;               //Cid
@property (nonatomic , copy)    NSString   *qid;               //请求id
@property (nonatomic , copy)    NSString   *ad_id;             //广告id
@property (nonatomic , copy)    NSString   *ad_type;           //广告资源类型
@property (nonatomic , copy)    NSString   *desc;              //广告描述
@property (nonatomic , copy)    NSString   *button_text;       //按钮文案
@property (nonatomic , copy)    NSString   *idea_title;        //创意标题
@property (nonatomic , copy)    NSString   *idea_id;           //创意id
@property (nonatomic , copy)    NSString   *seconds;           //跳过时间
@property (nonatomic , copy)    NSString   *is_ad;            //是否为广告
@property (nonatomic , assign)  BOOL        is_sync;            //同步上报
@property (nonatomic , copy)    NSString   *source_type;       //素材类型  1.图片 2.视频
@property (nonatomic , copy)    NSString   *source_img_url;    //图片地址
@property (nonatomic , copy)    NSString   *source_video_url;  //视频地址
@property (nonatomic , copy)    NSString   *target_type;       //跳转类型
@property (nonatomic , copy)    NSString   *target_value;      //跳转地址

@property (strong, nonatomic)   YXAdModelExposeURL *miaozhenExposeURL;
@property (strong, nonatomic)   YXAdModelExposeURL *admasterExposeURL;

// 更新为model
//@property (nonatomic , strong)  NSArray    *exposeUrlArray;    //曝光地址url
//@property (nonatomic , strong)  NSArray    *clickUrlArray;     //点击地址url


@property (nonatomic, copy)     NSString   *share_icon;        //分享图标
@property (nonatomic, copy)     NSString   *share_text;        //分享文案

- (instancetype) initWithCid:(NSString *)cid
                          qid:(NSString *)qid
                         dict:(NSDictionary *)dict;

@end

@interface YXAdExtendModel : NSObject

@property (nonatomic ,copy)    NSString   *star;       //主播
@property (nonatomic ,copy)    NSString   *topic;      //话题

@end

@interface YXVideoAdModel : NSObject
@property (nonatomic ,copy)  NSString   *YXAdVcnt;      //播放次数
@property (nonatomic ,copy)  NSString   *YXAdVend;      //来源
@property (nonatomic ,copy)  NSString   *YXAdLength;    //时长
@property (nonatomic ,copy)  NSString   *YXAdW;       //宽度
@property (nonatomic ,copy)  NSString   *YXAdH;      //高度
@property (nonatomic ,copy)  NSString   *YXAdSuid;      //视频作者id
@property (nonatomic ,copy)  NSString   *YXAdVer;       //视频类型
@property (nonatomic ,copy)  NSString   *YXAdLocation;  //发布时坐标
@property (nonatomic ,copy)  NSString   *YXAdFinishTime;//完成发布时间

@end
