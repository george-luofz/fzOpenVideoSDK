//
//  YXVideoAd.h
//  AdSDKDemo
//
//  Created by 罗富中 on 2017/5/22.
//  Copyright © 2017年 一下. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "YXVideoAdDelegate.h"
#import "YXAdModel.h"

/**
 页面跳转模型，当点击查看详情按钮触发yxVideoAdPlayerClick事件时返回该模型
 */
@interface YXVideoAdTargetModel : NSObject
@property(nonatomic,nullable,copy) NSString *targetType;    //跳转类型
@property(nonatomic,nullable,copy) NSString *targetValue;   //跳转值
@end

@interface YXVideoAd : NSObject
@property (nonatomic ,nullable,weak) id<YXVideoAdDelegate> videoAdDelegate;
@property (nonatomic ,nullable,copy) NSString              *cid;

 /**
  * 请求贴片广告
  * @param cid 广告位id，必填
  * @param infoModel 视频信息数据对象，可为nil
  * @param extendModel 扩展信息数据对象，可为nil
  */

- (void) requestVideoAd:(NSString *)cid
          infoModel:(YXVideoAdModel *)infoModel
        extendModel:(YXAdExtendModel *)extendModel;
/**
 * 获取播放器视图，请在请求成功时获取，否则为nil
 */
- (UIView *) getVideoAdView;
/**
 * 关闭贴片广告
 */
- (void) closeCinemaAd;

@end
