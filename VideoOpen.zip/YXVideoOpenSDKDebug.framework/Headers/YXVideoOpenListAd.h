//
//  YXVideoListAd.h
//  YXVideoOpenSDK
//
//  Created by 罗富中 on 2017/5/3.
//  Copyright © 2017年 yixia. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class YXAdModel;
/** 视频开放平台，视频源模型 */
@interface YXAdVideoOpenModel : NSObject
/** 视频id */
@property(nonatomic,nonnull,copy) NSString *vid;
/** 视频源地址 */
@property(nonatomic,nonnull,copy) NSString *url;
/** 视频封面图片地址 */
@property(nonatomic,nonnull,copy) NSString *pic_m;
/** 视频封面小图片地址，暂不使用*/
@property(nonatomic,nullable,copy) NSString *pic_s;
/** 视频作者昵称 */
@property(nonatomic,nonnull,copy) NSString *owner_nick;
/** 视频作者头像图片地址 */
@property(nonatomic,nullable,copy) NSString *owner_icon;
/** 视频作者id */
@property(nonatomic,nullable,copy) NSString *owner_suid;
/** 视频播放量 */
@property(nonatomic,assign) NSInteger vcnt;
/** 视频时长，单位为秒 */
@property(nonatomic,assign) NSInteger length;
/** 视频标题 */
@property(nonatomic,nullable,copy) NSString *title;
/** 视频副标题 */
@property(nonatomic,nullable,copy) NSString *title_f;
/** 视频类型 */
@property(nonatomic,assign) NSInteger type;
/** 视频状态，判断是否在用*/
@property(nonatomic,assign) NSInteger status;
/** 视频源宽度 */
@property(nonatomic,assign) NSInteger width;
/** 视频源高度 */
@property(nonatomic,assign) NSInteger height;
/** 视频来源 */
@property(nonatomic,nullable,copy) NSString *vend;
/** 是否是广告 */
@property(nonatomic,assign) BOOL isAd;
/** 视频发布时坐标 */
@property(nonatomic,nullable,copy) NSString *location;
/** 视频发布结束时间戳，单位毫秒 */
@property(nonatomic,assign) NSInteger finish_time;
@end

/** 视频开放平台代理*/
@protocol YXVideoOpenListAdDelegate <NSObject>
@optional
/**
 * 请求视频列表成功
 * @param videoList 返回视频列表，列表指定位置包含原生广告
 */
-(void)requestVideoOpenListAdSuccess:(UIView *) videoList;
/**
 * 请求视频列表失败
 * @param error 失败错误信息
 */
-(void)requestVideoOpenListAdFailed:(NSError *)error;
/**
 * 请求视频列表数据源成功
 * @param listDatas 视频列表数据源数组
 */
-(void)requestVideoListSuccess:(NSArray<YXAdVideoOpenModel*> *)listDatas;
/**
 * 请求视频列表数据源失败
 * @param error 请求失败信息
 */
-(void)requestVideoListError:(NSError *)error;

@end

@class YXAdCinemaAdParams;
@class YXAdExtendModel;
@class YXAdNativeAdParams;
@class YXAdVideoOpenModel;
@class YXAdExtendModel;
@class YXVideoOpenListAdParams;
@class YXVideoOpenListParams;
@protocol YXNativeAdDelegate;
@protocol YXVideoAdDelegate;

@interface YXVideoOpenListAd : NSObject
/** 设置视频开放平台广告代理 */
@property(nonatomic,weak) id <YXVideoOpenListAdDelegate> delegate;
/** 设置视频开放平台原生广告代理，用于请求原生广告时，从回调中获取数据 */
@property(nonatomic,weak) id <YXNativeAdDelegate> nativeAdDelegate;
/** 设置视频开放平台贴片广告代理，用于请求贴片广告时，从回调中获取数据 */
@property(nonatomic,weak) id <YXVideoAdDelegate> cinemaAdDelegate;

/** 根据指定参数，请求视频+广告列表 */
-(void) requestVideoOpenListWithParams:(YXVideoOpenListAdParams *)params;
/** 单独请求视频列表 */
-(void) requestVideoListWithParams:(YXVideoOpenListParams *)listParams;
/** 视频列表，视频开始播放时调用方法，用于播放开始上报 */
- (void) videoOpenListVideoStartToPlay:(YXAdVideoOpenModel *)model;
/** 视频列表，视频播放结束时调用方法，用于播放结束上报 */
- (void) videoOpenListVideoPlayFinished:(YXAdVideoOpenModel *)model;
/** 用于释放播放器资源等操作，SDK内部会在dealloc方法中自动释放，可不实现 */
- (void) closeListAd;
@end

/** 视频开放平台请求视频列表+广告参数对象 */
@interface YXVideoOpenListAdParams : NSObject
@property(nonatomic,nullable,strong) YXVideoOpenListParams *listParams;
@property(nonatomic,nullable,strong) YXAdNativeAdParams *nativeAdParams;
@property(nonatomic,nullable,strong) YXAdCinemaAdParams *cinemaAdParams;
@end

/** 视频开放平台请求视频列表参数对象 */
@interface YXVideoOpenListParams : NSObject
/** 视频列表id，必填 */
@property(nonatomic,nullable,copy) NSString *feedId;
/** 视频列表每页请求长度，默认为20条 */
@property(nonatomic,assign) NSInteger pageNumer;
/** 视频列表长度，必填 */
@property(nonatomic,assign) CGFloat videoListHeight;
/** 视频列表是否自动播放参数，默认为NO，即列表自动播放下一条 */
@property(nonatomic,assign) BOOL cannotAutoPlay;
@end

/** 视频开放平台请求原生广告参数对象 */
@interface YXAdNativeAdParams : NSObject
/** 原生广告广告位id，必填 */
@property(nonatomic,nullable,copy) NSString *cid;
/** 原生广告素材尺寸，可不传 */
@property(nonatomic,assign) CGPoint adSize;
/** 原生广告扩展参数，可不传 */
@property(nonatomic,nullable,strong) YXAdExtendModel *extendModel;
@end

/** 视频开放平台请求贴片广告参数对象 */
@interface YXAdCinemaAdParams : NSObject
/** 贴片广告广告位id，必填 */
@property(nonatomic,nullable,copy) NSString *cid;
/** 贴片广告扩展参数，可不传 */
@property(nonatomic,nullable,strong) YXAdExtendModel *extendModel;
@end


