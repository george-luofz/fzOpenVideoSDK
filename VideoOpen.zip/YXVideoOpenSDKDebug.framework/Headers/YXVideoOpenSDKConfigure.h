//
//  YXVideoOpenSDKConfigure.h
//  YXVideoOpenSDK
//
//  Created by 罗富中 on 2017/5/23.
//  Copyright © 2017年 罗富中. All rights reserved.
//

#import <Foundation/Foundation.h>
@class YXAdSDKParams;
@interface YXVideoOpenSDKParams : NSObject
/**
 * appId  一下广告SDK 应用id
 */
@property(nonatomic,nullable,copy) NSString *appId;
/**
 * channelId 一下广告SDK 渠道id
 */
@property(nonatomic,nullable,copy) NSString *channelId;
/**
 * debugMode  一下广告SDK 服务器配置开关，值为NO表示请求线上服务器，
 * 为YES表示请求测试服务器；默认为NO
 */
@property(nonatomic,assign) BOOL debugMode;

/**
 * partnerid   一下广告视频开放平台 合作方id
 */
@property(nonatomic,nullable,copy) NSString *partnerId;

@end

@interface YXVideoOpenSDKConfigure : NSObject
/**
 * 一下广告SDK公共配置方法
 * params 为YXAdSDKParams对象
 */
+ (void) configureWithSDKParams:(YXVideoOpenSDKParams *)params;

/**
 * 启用调试日志
 */
+ (void) enableLog;

@end

