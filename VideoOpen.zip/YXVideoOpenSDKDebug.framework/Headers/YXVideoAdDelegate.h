//
//  YXVideoAdDelegate.h
//  AdSDKDemo
//
//  Created by 罗富中 on 2017/5/22.
//  Copyright © 2017年 一下. All rights reserved.
//

#ifndef YXVideoAdDelegate_h
#define YXVideoAdDelegate_h
#import "YXAdError.h"

typedef NS_OPTIONS(NSUInteger, YXVideoAdRequestSuccessType) {
    YXVdieoAdRequestSuccessTypeNoData = 1, //请求广告成功，但无数据
    YXVdieoAdRequestSuccessTypeNormal = 2  //请求广告成功，数据返回正常
};

typedef NS_OPTIONS(NSUInteger, YXVideoAdPlayerExitType) {
    YXVideoAdPlayerExitTypePlayFailed = 1,    //视频播放失败，自动退出
    YXVideoAdPlayerExitTypePlayFinished = 2,  //视频播放结束，自动退出
    YXVideoAdPlayerExitTypeExitedByClick = 3, //点击查看详情按钮，自动退出
    YXVideoAdPlayerExitTypeExitedByUser = 4,  //开发者调用closeCinemaAd方法退出
};
@class YXVideoAdTargetModel;
@protocol YXVideoAdDelegate <NSObject>

/**
 请求广告成功
 @param successType 返回成功类型
 */
-(void) yxVideoAdRequestSuccess:(YXVideoAdRequestSuccessType) successType;

/**
 请求广告失败
 @param error 请求失败信息
 */
-(void) yxVideoAdRequestFailed:(YXAdError *)error;
@optional

/**
 点击查看详情按钮触发
 */
-(void) yxVideoAdPlayerClick:(YXVideoAdTargetModel *)targetModel;
/**
 贴片视频开始播放触发
 */
-(void) yxVideoAdPlayerStartToPlay;

/**
 贴片视频退出时触发
 @param exitType 退出类型
 */
-(void) yxVideoAdPlayerExited:(YXVideoAdPlayerExitType)exitType;
@end



#endif /* YXVideoAdDelegate_h */
